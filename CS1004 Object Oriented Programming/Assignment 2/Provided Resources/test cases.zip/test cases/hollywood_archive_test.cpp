
#include <gtest/gtest.h>
#include "hollywood.h"



TEST(Casting, MutualLinkEstablished) {
    Actor* a = addActor(1, "Tom Hanks", 67);
    Movie* m = addMovie(1, "Cast Away", 2000, 7.8f);
    castActor(a, m);

    EXPECT_EQ(a->filmography[0], m);
    EXPECT_EQ(m->cast[0], a);
    EXPECT_EQ(a->filmCount, 1);
    EXPECT_EQ(m->castCount, 1);
}

TEST(Casting, LatestRoleUpdates) {
    Actor* a = addActor(2, "Leo", 49);
    Movie* m1 = addMovie(2, "Inception", 2010, 8.8f);
    Movie* m2 = addMovie(3, "Revenant", 2015, 8.0f);
    castActor(a, m1);
    castActor(a, m2);

    EXPECT_EQ(a->latestRole, m2);
}

TEST(Casting, LeadActorIsFirstCast) {
    Actor* a1 = addActor(3, "Brad Pitt", 60);
    Actor* a2 = addActor(4, "Edward Norton", 54);
    Movie* m  = addMovie(4, "Fight Club", 1999, 8.8f);
    castActor(a1, m);
    castActor(a2, m);

    EXPECT_EQ(m->leadActor, a1);
}



TEST(Rival, CastingRejectedOnConflict) {
    Actor* a1 = addActor(5, "Actor A", 30);
    Actor* a2 = addActor(6, "Actor B", 30);
    Movie* m  = addMovie(5, "Conflict", 2020, 6.0f);

    addRival(a1, a2);
    castActor(a1, m);
    int result = castActor(a2, m);

    EXPECT_EQ(result, -1);
    EXPECT_EQ(m->castCount, 1);
}

TEST(Rival, RejectionLeavesNoPartialState) {
    Actor* a1 = addActor(7, "Actor C", 35);
    Actor* a2 = addActor(8, "Actor D", 35);
    Movie* m  = addMovie(6, "Clean Slate", 2021, 5.5f);

    addRival(a2, a1);
    castActor(a1, m);
    castActor(a2, m);

    EXPECT_EQ(a2->filmCount, 0);
    EXPECT_EQ(m->castCount,  1);
}


TEST(Remove, BothSidesUnlinked) {
    Actor* a = addActor(9,  "Cate B", 55);
    Movie* m = addMovie(7, "Tar", 2022, 7.3f);
    castActor(a, m);
    removeActorFromMovie(a, m);

    EXPECT_EQ(a->filmCount,  0);
    EXPECT_EQ(m->castCount,  0);
    EXPECT_EQ(m->leadActor,  nullptr);
    EXPECT_EQ(a->latestRole, nullptr);
}

TEST(Remove, LeadPromotedAfterRemoval) {
    Actor* a1 = addActor(10, "First",  40);
    Actor* a2 = addActor(11, "Second", 38);
    Movie* m  = addMovie(8, "Promo",  2019, 7.0f);
    castActor(a1, m);
    castActor(a2, m);
    removeActorFromMovie(a1, m);

    EXPECT_EQ(m->leadActor, a2);
}



TEST(Archive, ExactSearchReturnsMovie) {
    Archive* arch = createArchive(3);
    Movie* m = addMovie(9, "Dune", 2021, 8.0f);
    archiveInsert(arch, m);

    EXPECT_EQ(archiveSearch(arch, "Dune"), m);
}

TEST(Archive, FlaggedTitleFallback) {
    Archive* arch = createArchive(3);
    Movie* m = addMovie(10, "Dune Part Two", 2024, 8.5f);
    addFlaggedTitle(m, "Dune 2");
    archiveInsert(arch, m);

    EXPECT_EQ(archiveSearch(arch, "Dune 2"), m);
}

TEST(Archive, MissReturnsNull) {
    Archive* arch = createArchive(3);
    EXPECT_EQ(archiveSearch(arch, "Ghost"), nullptr);
}

TEST(Archive, DeleteThenSearchMisses) {
    Archive* arch = createArchive(3);
    Movie* m = addMovie(11, "Oppenheimer", 2023, 8.9f);
    archiveInsert(arch, m);
    archiveDelete(arch, "Oppenheimer");

    EXPECT_EQ(archiveSearch(arch, "Oppenheimer"), nullptr);
}


TEST(Retitle, NewTitleSearchable) {
    Archive* arch = createArchive(3);
    Movie* m = addMovie(12, "Old Name", 2010, 6.5f);
    archiveInsert(arch, m);
    retitleMovie(arch, m, "New Name");

    EXPECT_EQ(archiveSearch(arch, "New Name"), m);
}

TEST(Retitle, OldTitleBecomesFlag) {
    Archive* arch = createArchive(3);
    Movie* m = addMovie(13, "Working Title", 2011, 7.0f);
    archiveInsert(arch, m);
    retitleMovie(arch, m, "Final Title");

    EXPECT_EQ(archiveSearch(arch, "Working Title"), m);
    EXPECT_EQ(archiveSearch(arch, "Final Title"),   m);
}

