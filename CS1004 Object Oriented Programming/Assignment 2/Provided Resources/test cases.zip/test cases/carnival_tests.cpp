#include <gtest/gtest.h>
#include <cstring>
#include <sstream>
#include <iostream>
#include <functional>

#include "carnival.cpp"


static std::string capture_stdout(std::function<void()> fn) {
    std::ostringstream buf;
    std::streambuf* old = std::cout.rdbuf(buf.rdbuf());
    fn();
    std::cout.rdbuf(old);
    return buf.str();
}


TEST(OpsTable, ContortionistAllSlotsNonNull) {
    EXPECT_NE(contortionist_ops.greet,   nullptr);
    EXPECT_NE(contortionist_ops.perform, nullptr);
    EXPECT_NE(contortionist_ops.taunt,   nullptr);
    EXPECT_NE(contortionist_ops.cleanup, nullptr);
}

TEST(OpsTable, JugglerAllSlotsNonNull) {
    EXPECT_NE(juggler_ops.greet,   nullptr);
    EXPECT_NE(juggler_ops.perform, nullptr);
    EXPECT_NE(juggler_ops.taunt,   nullptr);
    EXPECT_NE(juggler_ops.cleanup, nullptr);
}

TEST(OpsTable, MimicAllSlotsNonNull) {
    EXPECT_NE(mimic_ops.greet,   nullptr);
    EXPECT_NE(mimic_ops.perform, nullptr);
    EXPECT_NE(mimic_ops.taunt,   nullptr);
    EXPECT_NE(mimic_ops.cleanup, nullptr);
}

TEST(OpsTable, OpsIsFirstField) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    Performer* p = (Performer*)(void*)&c;
    EXPECT_EQ(p->ops, &contortionist_ops);
}

TEST(OpsTable, JugglerOpsIsFirstField) {
    FireJuggler j{};
    j.ops = &juggler_ops;
    Performer* p = (Performer*)(void*)&j;
    EXPECT_EQ(p->ops, &juggler_ops);
}

TEST(OpsTable, MimicOpsIsFirstField) {
    ShadowMimic m{};
    m.ops = &mimic_ops;
    Performer* p = (Performer*)(void*)&m;
    EXPECT_EQ(p->ops, &mimic_ops);
}


TEST(Contortionist, GreetPrintsName) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));
    c.flexibility_score = 8;
    strncpy(c.signature_move, "Reverse Lotus Cannon", sizeof(c.signature_move));

    std::string out = capture_stdout([&]() { c.ops->greet(&c); });
    EXPECT_NE(out.find("Mirela"), std::string::npos);
}

TEST(Contortionist, PerformPrintsSignatureMove) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));
    c.flexibility_score = 7;
    strncpy(c.signature_move, "Iron Spiral", sizeof(c.signature_move));

    std::string out = capture_stdout([&]() { c.ops->perform(&c); });
    EXPECT_NE(out.find("Iron Spiral"), std::string::npos);
}

TEST(Contortionist, TauntPrintsRivalName) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));

    Contortionist rival{};
    rival.ops = &contortionist_ops;
    strncpy(rival.name, "Drazenko", sizeof(rival.name));

    std::string out = capture_stdout([&]() { c.ops->taunt(&c, &rival); });
    EXPECT_NE(out.find("Drazenko"), std::string::npos);
}


TEST(FireJuggler, GreetPrintsName) {
    FireJuggler j{};
    j.ops = &juggler_ops;
    strncpy(j.name, "Drazenko", sizeof(j.name));
    j.torch_count    = 2;
    j.torches_in_air = 2;
    j.torch_names    = (char**) malloc(2 * sizeof(char*));
    j.torch_names[0] = strdup("Ember");
    j.torch_names[1] = strdup("Singe");

    std::string out = capture_stdout([&]() { j.ops->greet(&j); });
    EXPECT_NE(out.find("Drazenko"), std::string::npos);

    j.ops->cleanup(&j);
}

TEST(FireJuggler, PerformNamesTorches) {
    FireJuggler j{};
    j.ops = &juggler_ops;
    strncpy(j.name, "Drazenko", sizeof(j.name));
    j.torch_count    = 2;
    j.torches_in_air = 2;
    j.torch_names    = (char**) malloc(2 * sizeof(char*));
    j.torch_names[0] = strdup("Blaze");
    j.torch_names[1] = strdup("Char");

    std::string out = capture_stdout([&]() { j.ops->perform(&j); });
    EXPECT_NE(out.find("Blaze"), std::string::npos);
    EXPECT_NE(out.find("Char"),  std::string::npos);

    j.ops->cleanup(&j);
}


TEST(ShadowMimic, PerformDelegatesToWatched) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));
    strncpy(c.signature_move, "Glass Spine", sizeof(c.signature_move));

    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = &c;

    std::string out = capture_stdout([&]() { m.ops->perform(&m); });
    EXPECT_NE(out.find("Glass Spine"), std::string::npos);
}

TEST(ShadowMimic, TauntTargetsWatched) {
    Contortionist watched{};
    watched.ops = &contortionist_ops;
    strncpy(watched.name, "Mirela", sizeof(watched.name));

    Contortionist bystander{};
    bystander.ops = &contortionist_ops;
    strncpy(bystander.name, "Nobody", sizeof(bystander.name));

    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = &watched;

    std::string out = capture_stdout([&]() { m.ops->taunt(&m, &bystander); });
    EXPECT_NE(out.find("Mirela"), std::string::npos);
}

TEST(ShadowMimic, NullWatchingDoesNotCrash) {
    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = nullptr;

    EXPECT_NO_FATAL_FAILURE(m.ops->perform(&m));
}

TEST(ShadowMimic, NullWatchingPrintsMessage) {
    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = nullptr;

    std::string out = capture_stdout([&]() { m.ops->perform(&m); });
    EXPECT_FALSE(out.empty());
}


TEST(RunShow, NoCrashWithMixedRoster) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));
    c.flexibility_score = 5;
    strncpy(c.signature_move, "Folded Crane", sizeof(c.signature_move));

    FireJuggler j{};
    j.ops = &juggler_ops;
    strncpy(j.name, "Drazenko", sizeof(j.name));
    j.torch_count    = 1;
    j.torches_in_air = 1;
    j.torch_names    = (char**) malloc(sizeof(char*));
    j.torch_names[0] = strdup("Flicker");

    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = &c;

    void* roster[] = { &c, &j, &m };
    EXPECT_NO_FATAL_FAILURE(run_show(roster, 3));

    j.ops->cleanup(&j);
}

TEST(RunShow, AllNamesAppearInOutput) {
    Contortionist c{};
    c.ops = &contortionist_ops;
    strncpy(c.name, "Mirela", sizeof(c.name));
    c.flexibility_score = 6;
    strncpy(c.signature_move, "Coil", sizeof(c.signature_move));

    FireJuggler j{};
    j.ops = &juggler_ops;
    strncpy(j.name, "Drazenko", sizeof(j.name));
    j.torch_count    = 1;
    j.torches_in_air = 1;
    j.torch_names    = (char**) malloc(sizeof(char*));
    j.torch_names[0] = strdup("Pyre");

    ShadowMimic m{};
    m.ops = &mimic_ops;
    strncpy(m.name, "The Mimic", sizeof(m.name));
    m.watching = &c;

    void* roster[] = { &c, &j, &m };
    std::string out = capture_stdout([&]() { run_show(roster, 3); });

    EXPECT_NE(out.find("Mirela"),    std::string::npos);
    EXPECT_NE(out.find("Drazenko"),  std::string::npos);
    EXPECT_NE(out.find("The Mimic"), std::string::npos);

    j.ops->cleanup(&j);
}


TEST(GrudgeBoard, EscalateNoCrash) {
    Contortionist a{}, t{};
    a.ops = &contortionist_ops; strncpy(a.name, "Aggressor", sizeof(a.name));
    t.ops = &contortionist_ops; strncpy(t.name, "Target",    sizeof(t.name));

    Grudge* g1 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g2 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g3 = (Grudge*) malloc(sizeof(Grudge));
    g1->aggressor = &a; g1->target = &t; g1->beneath = g2;
    g2->aggressor = &a; g2->target = &t; g2->beneath = g3;
    g3->aggressor = &a; g3->target = &t; g3->beneath = nullptr;

    EXPECT_NO_FATAL_FAILURE(escalate_grudges(g1));
    tear_down_board(g1);
}

TEST(GrudgeBoard, EscalateProducesOutput) {
    Contortionist a{}, t{};
    a.ops = &contortionist_ops; strncpy(a.name, "Aggressor", sizeof(a.name));
    t.ops = &contortionist_ops; strncpy(t.name, "Target",    sizeof(t.name));

    Grudge* g1 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g2 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g3 = (Grudge*) malloc(sizeof(Grudge));
    g1->aggressor = &a; g1->target = &t; g1->beneath = g2;
    g2->aggressor = &a; g2->target = &t; g2->beneath = g3;
    g3->aggressor = &a; g3->target = &t; g3->beneath = nullptr;

    std::string out = capture_stdout([&]() { escalate_grudges(g1); });
    EXPECT_FALSE(out.empty());
    tear_down_board(g1);
}

TEST(GrudgeBoard, TearDownNoCrash) {
    Contortionist dummy{};
    dummy.ops = &contortionist_ops;
    strncpy(dummy.name, "X", sizeof(dummy.name));

    Grudge* g1 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g2 = (Grudge*) malloc(sizeof(Grudge));
    Grudge* g3 = (Grudge*) malloc(sizeof(Grudge));
    g1->aggressor = &dummy; g1->target = &dummy; g1->beneath = g2;
    g2->aggressor = &dummy; g2->target = &dummy; g2->beneath = g3;
    g3->aggressor = &dummy; g3->target = &dummy; g3->beneath = nullptr;

    EXPECT_NO_FATAL_FAILURE(tear_down_board(g1));
}


TEST(ReplacePerformer, SlotHoldsNewOpsTable) {
    Contortionist* c = (Contortionist*) malloc(sizeof(Contortionist));
    c->ops = &contortionist_ops;
    strncpy(c->name, "Mirela", sizeof(c->name));
    c->flexibility_score = 4;
    strncpy(c->signature_move, "Old Move", sizeof(c->signature_move));

    void* roster[1];
    roster[0] = c;

    FireJuggler* j = (FireJuggler*) malloc(sizeof(FireJuggler));
    j->ops = &juggler_ops;
    strncpy(j->name, "Drazenko", sizeof(j->name));
    j->torch_count    = 1;
    j->torches_in_air = 1;
    j->torch_names    = (char**) malloc(sizeof(char*));
    j->torch_names[0] = strdup("Newfire");

    replace_performer(roster, 0, j);

    Performer* p = (Performer*) roster[0];
    EXPECT_EQ(p->ops, &juggler_ops);

    p->ops->cleanup(roster[0]);
    free(roster[0]);
}

TEST(ReplacePerformer, RunShowProducesNewName) {
    Contortionist* c = (Contortionist*) malloc(sizeof(Contortionist));
    c->ops = &contortionist_ops;
    strncpy(c->name, "OldAct", sizeof(c->name));
    c->flexibility_score = 3;
    strncpy(c->signature_move, "Vanish", sizeof(c->signature_move));

    void* roster[1] = { c };

    FireJuggler* replacement = (FireJuggler*) malloc(sizeof(FireJuggler));
    replacement->ops = &juggler_ops;
    strncpy(replacement->name, "NewAct", sizeof(replacement->name));
    replacement->torch_count    = 1;
    replacement->torches_in_air = 1;
    replacement->torch_names    = (char**) malloc(sizeof(char*));
    replacement->torch_names[0] = strdup("Blaze");

    replace_performer(roster, 0, replacement);

    std::string out = capture_stdout([&]() { run_show(roster, 1); });
    EXPECT_NE(out.find("NewAct"), std::string::npos);

    ((Performer*)roster[0])->ops->cleanup(roster[0]);
    free(roster[0]);
}


int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
