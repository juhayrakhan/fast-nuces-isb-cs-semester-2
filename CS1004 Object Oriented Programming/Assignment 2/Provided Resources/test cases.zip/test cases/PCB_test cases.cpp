#include <gtest/gtest.h>
#include <cstring>
#include <cmath>
#include "solution.h"


TEST(Part0_Loading, LoadsAtLeastOnePlayers)
{
    Player* squad = nullptr;
    int count = loadSquad(squad, "players.csv");

    EXPECT_GT(count, 0) << "loadSquad returned 0 -- did it open players.csv?";

    ASSERT_NE(squad, nullptr) << "squad pointer is still nullptr after loading";

    EXPECT_GT(strlen(squad[0].name), 0u) << "First player's name is empty";

    delete[] squad;
}
TEST(Part0_Loading, CorrectPlayerCount)
{
    Player* squad = nullptr;
    int count = loadSquad(squad, "players.csv");

    EXPECT_EQ(count, 22)
        << "Expected 22 players from players.csv but got " << count;

    delete[] squad;
}
TEST(Part0_Loading, BabarAzamFieldsAreCorrect)
{
    Player* squad = nullptr;
    int count = loadSquad(squad, "players.csv");
    ASSERT_GT(count, 0);

    // Assume Babar Azam is the first player (first line in CSV)
    Player& babar = squad[0];

    EXPECT_STREQ(babar.name, "Babar Azam");
    EXPECT_EQ(babar.age, 29);
    EXPECT_STREQ(babar.role, "Batsman");
    EXPECT_FLOAT_EQ(babar.battingAvg, 48.5f);
    EXPECT_EQ(babar.fitnessLevel, 90);
    EXPECT_EQ(babar.fatigueLevel, 22);

    delete[] squad;
}
TEST(Part1_SquadSelection, RejectsTooFewPlayers)
{
    const int SIZE = 10;
    Player dummySquad[SIZE];
    for (int i = 0; i < SIZE; i++) {
        strcpy(dummySquad[i].name,  "Test Player");
        strcpy(dummySquad[i].role,  "Batsman");
        dummySquad[i].age          = 25;
        dummySquad[i].fitnessLevel = 80;
        dummySquad[i].fatigueLevel = 20;
        dummySquad[i].pressureIndex   = 8.0f;
        dummySquad[i].influenceScore  = 8.0f;
        dummySquad[i].recentForm      = 7.0f;
        dummySquad[i].battingAvg      = 35.0f;
        dummySquad[i].bowlingAvg      = 0.0f;
        dummySquad[i].economy         = 0.0f;
        dummySquad[i].experienceScore = 7.0f;
        dummySquad[i].matchesPlayed   = 50;
        dummySquad[i].adaptabilityRating = 7.0f;
        dummySquad[i].partnershipScore   = 7.0f;
        dummySquad[i].selected = true;
    }
    bool valid = validateSquad(dummySquad, SIZE);
    EXPECT_FALSE(valid)
        << "validateSquad accepted only 10 players -- it must require exactly 15";
}
TEST(Part2_PlayerCard, CompositeScoreIsPositive)
{
    Player p;
    strcpy(p.name,  "Shaheen Afridi");
    strcpy(p.role,  "Bowler");
    p.age            = 24;
    p.battingAvg     = 5.1f;
    p.bowlingAvg     = 22.3f;
    p.economy        = 7.8f;
    p.recentForm     = 6.5f;
    p.fitnessLevel   = 80;
    p.experienceScore= 8.0f;
    p.matchesPlayed  = 60;
    p.influenceScore = 8.4f;
    p.pressureIndex  = 9.2f;
    p.fatigueLevel   = 38;
    p.adaptabilityRating = 7.0f;
    p.partnershipScore   = 6.5f;
    p.selected       = true;

    PlayerCard card(p);
    EXPECT_GT(card.getComposite(), 0.0f)
        << "Composite score should be positive for a real player";
}
TEST(Part2_PlayerCard, StrongerPlayerWinsComparison)
{
    Player elite;
    strcpy(elite.name,  "Elite Player");
    strcpy(elite.role,  "Batsman");
    elite.age            = 28;
    elite.battingAvg     = 60.0f;
    elite.bowlingAvg     = 0.0f;
    elite.economy        = 0.0f;
    elite.recentForm     = 9.5f;
    elite.fitnessLevel   = 99;
    elite.experienceScore= 9.8f;
    elite.matchesPlayed  = 100;
    elite.influenceScore = 9.8f;
    elite.pressureIndex  = 9.8f;
    elite.fatigueLevel   = 10;
    elite.adaptabilityRating = 9.8f;
    elite.partnershipScore   = 9.8f;
    elite.selected       = true;

    Player weak;
    strcpy(weak.name,  "Weak Player");
    strcpy(weak.role,  "Batsman");
    weak.age            = 20;
    weak.battingAvg     = 5.0f;
    weak.bowlingAvg     = 0.0f;
    weak.economy        = 0.0f;
    weak.recentForm     = 1.0f;
    weak.fitnessLevel   = 30;
    weak.experienceScore= 1.0f;
    weak.matchesPlayed  = 5;
    weak.influenceScore = 1.0f;
    weak.pressureIndex  = 1.0f;
    weak.fatigueLevel   = 90;
    weak.adaptabilityRating = 1.0f;
    weak.partnershipScore   = 1.0f;
    weak.selected       = true;

    PlayerCard cardElite(elite);
    PlayerCard cardWeak(weak);

    EXPECT_TRUE(cardElite > cardWeak)
        << "Elite player should be > weak player";
    EXPECT_FALSE(cardWeak > cardElite)
        << "Weak player should NOT be > elite player";
}
TEST(Part4_Simulation, WinProbabilityIsInValidRange)
{
    struct TestCase { float sA; float sB; float cond; };
    TestCase cases[] = {
        { 90.0f, 90.0f, 1.0f },  
        { 95.0f, 50.0f, 1.2f },  
        { 40.0f, 95.0f, 0.8f },   
        { 70.0f, 70.0f, 0.8f },   
        { 85.0f, 60.0f, 1.0f },  
    };
    int numCases = 5;

    for (int i = 0; i < numCases; i++) {
        float prob = computeWinProbability(
            cases[i].sA, cases[i].sB, cases[i].cond);

        EXPECT_GE(prob, 0.0f)
            << "Win probability below 0 for test case " << i;
        EXPECT_LE(prob, 1.0f)
            << "Win probability above 1 for test case " << i;
    }
}
