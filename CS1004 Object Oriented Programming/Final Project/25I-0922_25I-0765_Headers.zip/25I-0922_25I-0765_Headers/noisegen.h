#include <cmath>

double lerpp(double a, double b, double t) { return a + t * (b - a); }
double getNoise(int x, int seed) {
	int n = x + seed * 57;
	n = (n << 13) ^ n;
	return (1.0 - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824.0);
}
double sampleNoise(double x, int seed) {
	int x0 = floor(x);
	double t = x - x0;
	return lerpp(getNoise(x0, seed), getNoise(x0 + 1, seed), t);
}
double fractalNoise(double x, int seed, int layers, double roughness) {
	double total = 0, frequency = 1.0, amplitude = 1.0, maxValue = 0;
	for (int i = 0; i < layers; i++) {
		total += sampleNoise(x * frequency, seed + i) * amplitude;
		maxValue += amplitude;
		amplitude *= roughness;
		frequency *= 2;
	}
	return (maxValue == 0) ? 0 : total / maxValue;
}