#pragma once
#include "../25I-0922_25I-0765_Headers/Element_Entity.h"
using namespace sf;

class Bullet : public Element {
protected:
	int dirx, diry;
	SpriteData* blast;
public:
	Bullet(int x, int dirx, int y, int diry) : Element("bullet", x, y) {}
	Bullet() : Element("bullet", 0, 0) {}
	void shoot() {
		this->x += dirx;
		if (x > screen_x) exists = false;
		this->y += diry;
		if (y > screen_y) exists = false;
	}
	~Bullet(){}
};

class MeleeAttack {
protected:
	bool BreakShields;
	int damage;
public:
	MeleeAttack(int damage, bool canBreakShields = false) :
		damage(damage), BreakShields(canBreakShields) {
	}
	bool canBreakShields() const {
		return BreakShields;
	}
	int getMeleeDam() { return damage; }
	void setMelDam(int a) { damage = a; }
};

class Enemy;
class Vehicle;
class Pistol;
class Projectile;

class Fire : public Element {
public:
	Fire() : Element("fire", x, y) {}
	void shoot(int x, int y, int a, Entity& e) {
		int l = 0;
		while (l < l + block_wid * 5) {
			this->x += 1;
			if (is_colliding(this, &e)) {
				e.reduceHP(7);
			} l++;
		}
	}
};
class Rocket : public Element {
public:
	Rocket() : Element("rocket", 10, 10, 1) {}
	void blast(Entity* e) {
		int dx = e->x - this->x;
		int dy = e->y - this->y;
		int blast_radius = dx * dx + dy * dy;
		if (blast_radius <= 3)
			e->reduceHP(7);
	}
	void aiming(int x, int y, int d, Entity* e) {
		this->x = x; this->y = y;
		double speed = 3;
		int target_x = x + 15; int target_y = x + 15;
		double ang = atan(static_cast<double>((y - target_x)) / (x - target_y));
		double new_x = cos(ang);
		double new_y = sin(ang);
		while (x < target_x && y < target_y) {
			this->x += (new_x * speed);
			this->y += (new_y * speed);
			if (is_colliding(this, e)) {
				blast(e); break;
			}
		}
	}
};
class Weapon {
protected:
	int damage; int posX, posY;
	double speed;
	int direction;
	double firerate;
	Projectile* proj;

	int dirx, diry; // -1,0,1

public:
	Fire fire;
	SpriteData* weaponSprite;
	double wp_getFire() {
		return firerate;
	}
	void wp_setFire(double d) {
		firerate = d;
	}
	int wx, wy;
	Weapon() {
		damage = 3;
		speed = 3;
	}
	virtual void aiming(int wx, int wy, int d) {   //depend on key pressed in main
		int x = wx + block_wid;
		int y = block_heig;
		double ang = atan(static_cast<double>((y - wy)) / (x - wx));
		double new_x = cos(ang);
		double new_y = sin(ang);
		while (x < wx * 9 && y < wy * 9) {
			x += (new_x * speed);
			y += (new_y * speed);
		}
	}
	virtual void blast(int, int, int) {
		;
	}
	virtual void shoot(int, int, int, Entity& e) {};
	/*  after making the paler    wx= palyer.x    wy= player.y
	  others lke on right left   wx+=1  wy+=1      */
};


class Grenade : public Weapon {
protected:
	int reduce_hp;
	int blastRadius;
public:
	Rocket roc;
	Grenade() {
		reduce_hp = 5;
		blastRadius = block_wid * 3;
	}
	void blast(int x, int y, int d, Entity* e) {}
	void blast(int, int, int) {
		;
	}
	//virtual void shoot(int x, int y, int a, Entity& e);

};
class Missile : public Weapon {
	const char* type;
public:
	Rocket roc;
	Missile(const char* type) : type(type) { damage = 5; }
	void blast(int x, int y, int d, Entity* e) {
		if (compare(type, "projectile")) {
			aiming(x, y, d);
			for (int i = 0; i < block_wid * 3; i++) {
				e->setHP(e->getHP() - damage); posX += 1; posY += 1;
			}
		}
		else if (compare(type, "vertical"))
			for (int i = 0; i < block_wid * 3; i++) {
				e->setHP(e->getHP() - damage); posX += 1; posY += 1;
			}
		else if (compare(type, "horizontal"))
			for (int i = 0; i < block_wid * 3; i++) {
				e->setHP(e->getHP() - damage); posX += 1; posY += 1;
			}
	}
};

class HandGrenade : public Grenade {
public:
	Rocket roc;
	Missile mis();
	HandGrenade() {
		damage = 5;
	}

	void blast(int x, int y, int d, Entity* e) {
		roc.aiming(this->posX + 10, this->posY, 1, e);
	}
};
class FireBombGrenade : public Grenade {
public:
	Rocket roc;
	void blast(int x, int y, int d, Entity* e) {
		roc.aiming(this->posX + 10, this->posY, 1, e);
	}
};


//______________________
class FireArm : public Weapon {
protected:
	int ammo;
	double FireRate;
	int num_blocks;

public:
	Fire fire;
	FireArm() {
		damage = 3;
		FireRate = 3;
	}
	virtual void shoot(int x, int y, int a, Entity& e) {
		fire.shoot(x, y, a, e);
	}
};
class Pistol : public FireArm {
public:
	Bullet b;
	Pistol() {}
	void shoot(int x, int y, int a, Entity& e) {
		b.shoot();
	}
};

class FlameShot : public FireArm {
protected:
	double speed;
public:
	Bullet bull;
	FlameShot() {
		damage = 2;
	}
	void shoot(int x, int y, int a, Entity& e) {
		bull.shoot();
	}

};
class HeavyMachineGun : public FireArm {    //on key pressing it triggers
protected:
	double FireRate;
public:
	HeavyMachineGun() {
		FireRate *= 2;
	}
	void shoot(int x, int y, int a, Entity& e) {
		for (int i = x; i < block_wid * 5; i++) {
			e.setHP(e.getHP() - damage);
		}
	}
};

class RocketLauncher : public FireArm {
protected:
public:
	Rocket roc;
	RocketLauncher() {
		damage = num_blocks + 2;
	}
	void blast(int x, int y, int d, Entity* e) {
		roc.aiming(this->posX + 10, this->posY, 1, e);
	}
};
class Laser : public Element {
public:
	Laser() : Element("laser", x, y) {}
	void shoot(int x, int y, int a, Entity& e) {
		while (this->x <= screen_x) {
			if (is_colliding(this, &e)) {
				e.setHP(0); break;
			}
		}
	}
};
class LaserGun : public FireArm {
protected:
	double FireRate;
	//insatntly kills on impact
public:
	Laser laser;
	void shoot(int x, int y, int d, Entity& e) {
		laser.shoot(x, y, d, e);

	}
};
class Projectile : public Weapon {        //hre element 1 should be bullet etc
	const char* type;
	int start, end;
public:
	Projectile(const char* t) : type(t) {}
	void shoot(const char* type, Element* e1, Element* e2) {
		if (type == "vertical")
			for (int i = 0; !(is_colliding(e1, e2)); i++)
				e1->y += 1;
		if (type == "horizontal")
			for (int i = 0; !(is_colliding(e1, e2)); i++)
				e1->x += 1;
		if (type == "projectile")
			for (int i = 0, j = 0; !(is_colliding(e1, e2)); i++, j++) {
				int x = wx + block_wid;
				int y = block_heig;
				double ang = atan((y - wy) / (x - wx));
				double new_x = cos(ang);
				double new_y = sin(ang);
			}

	}

};

class Food;

class Enemy : public Entity {
protected:
	int batchSize;
	Food* drop;
	Weapon weapon;
public:
	int shootTimer;
	Enemy(const char* name) : Entity(name, 0, 0, 0, 0, 0), shootTimer(120) {}
	~Enemy() {}
};


class MummyWarrior : public Enemy {
public:
	MummyWarrior() : Enemy("mummy") {
		type = 'm'; hp = 5;
	}
};
class Zombie : public Enemy {
	Pistol p;
public:
	Zombie() : Enemy("zombie") {
		type = 'z';
		hp = 5;
	}

};

class Player;

//enemyattach
class RebelSoldier : public Enemy {
public:
	Pistol pistol;
	RebelSoldier(int x = 100) : Enemy("rebelSoldier") {
		hp = 2;
	}
	void sprite_load() {};
	void damageEnemy(int n) {
		hp -= n;
	}
};

class ShieldedSoldier : public Enemy {
public:
	Pistol pistol;
	bool has_shield;   //works only for horizontal attacks
	ShieldedSoldier() : Enemy("Soldier") {
		hp = 5;
		has_shield = true;
	}
	void sprite_load() {};
	void damageEnemy(int n, const char* weapon) {
		if (has_shield && compare(weapon, "bullet"))
			return;
		hp -= n;
	}
};



class BazookaSoldier : public Enemy {   //slogetW()
public:
	RocketLauncher rocket;
	BazookaSoldier() : Enemy("bazooka") {
		hp = 2;
	}
	void sprite_load() {};
	void damageEnemy(int n) {
		hp -= n;
	}
};
class GrenadeSoldier : public Enemy {
public:
	Grenade* grenade;
	GrenadeSoldier() : Enemy("gr_soldier") {
		hp = 2;
	}
	void sprite_load() {};
	void damageEnemy(int n) {
		hp -= n;
	}
};
class Paratrooper : public Enemy {
	int startpos = screen_y;
public:
	/* if collide then that is the end position and paratrop sprite disappears*/
	Enemy* enemy;
	Paratrooper() : Enemy("paratrooper") {
		char ch[4] = { 'a','b','c','d' };
		int inf = rand() % 4;
		if (inf == 0) {
			enemy = new RebelSoldier();
		}
		if (inf == 1)
			enemy = new ShieldedSoldier();
		if (inf == 2)
			enemy = new BazookaSoldier();
		if (inf == 3)
			enemy = new GrenadeSoldier();
	}
	~Paratrooper() { delete enemy; }
};

class Alien : public Enemy {
public:
	Alien() : Enemy("alien") {
		hp = 3;
	}
};

class Vehicle : public Entity {
public:
	CoolDown cool;
	SpriteData* sprite;
	Vehicle() : Entity("vehicle", 0, 0, 0, 0, 0), cool(120) {
		cool.start();
	}
	virtual void dropGrenade(Player* p) {}
	virtual void fly(Entity& e) { ; }
	void update() {
		this->x += 1;
	}
};


class FlyingTara : public Vehicle {
public:
	HandGrenade* gr;
	FlyingTara() : Vehicle() {
		hp = 7;
		gr = new HandGrenade();
	}
	void dropGrenade(Player* p);

	void vehUpdate(Player* p) {
		cool.advance();
		update();
		dropGrenade(p);
		cool.start();
	}
};
class M15A : public Vehicle {
public:
	HandGrenade* gr;      //rocket and missile are only separated through sprite
	M15A() : Vehicle() {
		hp = 7;
		gr = new HandGrenade();
	}
	void dropGrenade(Player* p);
	void vehUpdate(Player* p) {
		cool.advance();
		update();
		dropGrenade(p);
		cool.start();
	}
};
class Enemy_sub :public Vehicle {
public:
	RocketLauncher  rock;
	Enemy_sub() : Vehicle() {
		hp = 7;

	}
	void dropGrenade(Player* p);
	void vehUpdate(Player* p) {
		cool.advance();
		update();
		dropGrenade(p);
		cool.start();
	}
};
class MetalSlug : public Vehicle {
public:
	FlameShot flam;
	void dropGrenade(Player* p);
	void shoot(Player* p);
	void vehUpdate(Player* p) {
		cool.advance();
		update();
		shoot(p);
		cool.start();
	}

};
class SlugFlyer : public Vehicle {   //if keyboard is up key pressed
public:
	Missile missile[4] = { Missile("projectile"),Missile("projectile"),Missile("projectile"),Missile("projectile") };
	void dropGrenade(Player* p);
	void fly(Entity& e) {
		e.setY(getY() + 10);
	}
	void vehUpdate(Player* p) {
		cool.advance();
		update();
		dropGrenade(p);
		cool.start();
	}
};
class SlugMariner : public Vehicle {
public:
	Missile missile[3] = { Missile("projectile"),Missile("horizontal"),Missile("vertical") };
	void dropGrenade(Player* p);
	void vehUpdate(Player* p) {
		cool.advance();
		update();
		dropGrenade(p);
		cool.start();
	}
};
class AmbhibousSlug : public Vehicle {
	Vehicle* veh;
	void dropGrenade(Player* p) override {}
	//if biome == aquatic and collision with Water
	//veh = new SlugFlyer();
};