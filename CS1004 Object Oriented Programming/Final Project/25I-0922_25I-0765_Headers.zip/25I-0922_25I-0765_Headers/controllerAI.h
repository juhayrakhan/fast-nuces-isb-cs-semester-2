#pragma once
#include<iostream>
#include"../25I-0922_25I-0765_Headers/Header.h"
#include"../25I-0922_25I-0765_Headers/AIMode.h"

class Controller {
	Player* p; Enemy* e; Vehicle* v;
	Controller(Player*& p, Enemy* e, Vehicle* v) {
		this->p = p;
		this->e = e;
		this->v = v;
	}
};