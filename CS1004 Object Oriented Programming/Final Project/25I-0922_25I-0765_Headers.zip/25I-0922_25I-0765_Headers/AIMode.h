#pragma once
#include<iostream>
#include"../25I-0922_25I-0765_Headers//Header.h"


class Neuron {
	int input; int output; int weight;
};
struct ConnectionGen {
	int innovation; bool is_on; int inputId, outputId;
	double weight;
	/*ConnectionGen* con;   // linked lst
	void turn_off(ConnectionGen* head) {
		while (head->con != nullptr) {
			head->con = nullptr; head = head->con;
		}
		is_on = false;
	}*/
};
struct NodeGen {
	int id; double bias; const char* type;  const char* state;
	const char* s1;  int val1;
	NodeGen(int t) {
		val1 = 0;
		if (t == 1)
			s1 = "INPUT";
		else if (t == 2)
			s1 = "HIDDEN";
		else
			s1 = "OUTPUT";
	}
	double activation(double x) {
		x = x * 4.9;
		return 0.5 * (x / (1.0 + std::abs(x))) + 0.5;
	}
	double valuesAct = 0, value = 0;
	void takeValues(double val) {
		value += val;
		valuesAct += activation(val);
	}
	void rst() {
		value = 0; valuesAct = 0;
	}
};
struct Genome {
	int id;
	ConnectionGen* conn; int c1;
	NodeGen* node; int c2;
	double fitness;

};