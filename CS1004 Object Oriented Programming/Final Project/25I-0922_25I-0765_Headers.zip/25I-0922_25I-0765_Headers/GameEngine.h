#pragmaML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include "../25I-0922_25I-0765_Headers/Header.h"
#include "../25I-0922_25I-0765_Headers/Player.h"
#include "../25I-0922_25I-0765_Headers/noisegen.h"
using namespace sf;
using namespace std;

class Biome {
	const char* name;
	int   start, end;
	int   seed;
	int* localHeights;
	int   cols;
	int    layers;
	double roughness, zoom;
	int    baseline, maxAmp;
public:
	Biome(const char* name, int start, int end,	int layers = 6, double roughness = 0.3,	double zoom = 0.03, int baseline = height - 6, int maxAmp = 3)
		: name(name), start(start), end(end), layers(layers), roughness(roughness), zoom(zoom),	baseline(baseline), maxAmp(maxAmp), cols(end-start) {
		localHeights = new int[cols];
		seed = rand();
		generate();
	}
	void generate() {
		for (int i = 0; i < cols; i++) {
			double n = fractalNoise((start + i) * zoom, seed, layers, roughness);
			localHeights[i] = baseline - (n * maxAmp);
		}
	}
	int heightAt(int world) const {
		int i = world - start;
		if (i < 0) i = 0;
		if (i > cols -1) i = cols - 1;
		return localHeights[i];
	}
	const char* getName()   const { return name; }
	int getStart()       const { return start; }
	int getEnd()         const { return end; }
	bool inRange(int check) const { return check >= start && check <= end; }
};

const int MAX_ENEMIES = 64;

class ElementManager {
	Element** blocks;
	int blockcount;
	SpriteData* bg;
	CoolDown gravDelay;

	int worldHeights[2000];

	Player* player;
	Bullet* playerbullet;

	Texture wallTex1;
	Sprite wallSprite1;
	Texture waterTex;
	Sprite waterSprite;

	Enemy* enemies[MAX_ENEMIES];
	Food* drops[MAX_ENEMIES];
	int dropCount;
	int enemyCount;

	char** lvl;
	int camX;

	SoundBuffer runb, shootb, landb, enemyb;
	Sound run, shoot, land, enemy;
	Music bgMusic;

	void loadplayers() {
		AnimRow InitialDrop = { 7, 5, 29, 240 };
		player = new Player("Marco Rossi", 409, -150, 60, 0, 10);
		player->setIntroAnimation(new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Intro.png", InitialDrop, 3, 5, false));
		player->totalHeight = player->topOffsetY + 54;
		player->totalWidth = 21 * 3;
		AnimRow Idle = { 5, 5, 32, 28 };
		AnimRow Shoot = { 3, 3, 53, 23 };
		player->setTopState(TOP_IDLE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Idle.png", Idle, 3, 15));
		player->setTopState(TOP_SHOOT, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Shoot.png", Shoot, 3, 15));
		player->setTopState(TOP_MELEE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Idle.png", Idle, 3, 15));
		
		Idle = { 1, 0, 21, 16 };
		AnimRow Run = { 3, 2, 20, 20 };
		AnimRow Jump = { 3, 4, 20, 24 };
		AnimRow Death = { 8, 1, 39, 31 };
		player->setBotState(BOT_IDLE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Idle.png", Idle, 3, 15));
		player->setBotState(BOT_RUN, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Run.png", Run, 3, 10));
		player->setBotState(BOT_JUMP, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Jump.png", Jump, 3, 10));
		player->setDeathAnimation(new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Death.png", Death, 3, 10));
	
	
		AnimRow foodRow = { 1, 0, 16, 16 };
	}
	void loadAudio() {
		runb.loadFromFile("../25I-0922_25I-0765_Assets/Audio/run.wav");     run.setBuffer(runb);
		shootb.loadFromFile("../25I-0922_25I-0765_Assets/Audio/shoot.wav");  shoot.setBuffer(shootb);
		landb.loadFromFile("../25I-0922_25I-0765_Assets/Audio/land.wav");   land.setBuffer(landb);
		bgMusic.openFromFile("../25I-0922_25I-0765_Assets/Audio/bgm.ogg");
		bgMusic.setVolume(0.3);
		bgMusic.setLoop(true);
		bgMusic.play();
	}
	void loadbg() {
		AnimRow data = { 1,0,792,176 };
		bg = new SpriteData("../25I-0922_25I-0765_Assets/backgrounds.png", data, (screen_y / 176.0), 0, false);
	}
	void loadEnemies() {
		enemyCount = 0;
		for (int i = 0; i < MAX_ENEMIES; i++) enemies[i] = nullptr;

		AnimRow RSIdle = { 4, 0, 39, 37 }, 
			RSAttack = { 3, 2, 22, 24 },
			RSDead = { 6, 3, 38, 48 };

		AnimRow SSIdle = { 3, 2, 22, 26 },
			SSAttack = { 3, 2, 22, 26 }
		,SSDead = { 5, 2, 24, 26 };

		AnimRow GSIdle = { 4, 2, 20, 24 }, 
			GSAttack = { 3, 2, 22, 24 },
		GSDead = { 5, 2, 24, 24 };

		const int SPAWN_INTERVAL = width / 20;
		for (int group = 0; group < 10; group++) {
			int baseCol = (group + 1) * SPAWN_INTERVAL;
			int worldX = baseCol * cell_size;
			int worldY = (worldHeights[baseCol] - 1) * cell_size;

			if (enemyCount < MAX_ENEMIES) {
				RebelSoldier* rs = new RebelSoldier();
				rs->setX(worldX);
				rs->setY(worldY);
				rs->setSprite(EIDLE, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Run.png", RSIdle, 2, 12));
				rs->setSprite(EATTACK, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Attack.png", RSAttack, 2, 10));
				rs->setSprite(EDEAD, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Dead.png", RSDead, 2, 10, false));
				enemies[enemyCount++] = rs;
			}
			if (enemyCount < MAX_ENEMIES) {
				ShieldedSoldier* ss = new ShieldedSoldier();
				ss->setX(worldX + 64);
				ss->setY(worldY);
				ss->setSprite(EIDLE, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Run.png", RSIdle, 2, 12));
				ss->setSprite(EATTACK, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Attack.png", RSAttack, 2, 10));
				ss->setSprite(EDEAD, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Dead.png", RSDead, 2, 10, false));
				enemies[enemyCount++] = ss;
			}
			if (enemyCount < MAX_ENEMIES) {
				GrenadeSoldier* gs = new GrenadeSoldier();
				gs->setX(worldX + 128);
				gs->setY(worldY);
				gs->setSprite(EIDLE, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Run.png", RSIdle, 2, 12));
				gs->setSprite(EATTACK, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Attack.png", RSAttack, 2, 10));
				gs->setSprite(EDEAD, new SpriteData("../25I-0922_25I-0765_Assets/Rebel Soldier Dead.png", RSDead, 2, 10, false));
				enemies[enemyCount++] = gs;
			}
		}
	}
	void buildLvl(Biome** biomes, int biomeCount) {
		lvl = new char* [height];
		for (int r = 0; r < height; r++) {
			lvl[r] = new char[width];
			for (int c = 0; c < width; c++) lvl[r][c] = '\0';
		}
		for (int col = 0; col < width; col++) {
			int h;
			for (int b = 0; b < biomeCount; b++) if (biomes[b]->inRange(col)) {
				h = biomes[b]->heightAt(col);
				if (h < 0)h = 0;
				break;
			}
			worldHeights[col] = h;
			lvl[h][col] = 'g';
			for (int row = h + 1; row < height; row++) lvl[row][col] = 'g';
		}
		int spawnCol = 409 / cell_size;
		wallTex1.loadFromFile("../25I-0922_25I-0765_Assets/blocks/stone.png");
		wallSprite1.setTexture(wallTex1);
	}
public:
	ElementManager(Biome** biomes, int biomeCount) : gravDelay(4), camX(0), blockcount(0){
		blocks = nullptr;
		dropCount = 0;
		srand(time(0));
		loadbg();
		loadplayers();
		loadAudio();
		loadEnemies();
		buildLvl(biomes, biomeCount);
	}
	void collideLvlEnemy(Enemy* e) {
		int pw = e->getW(); if (pw == 0) pw = 48;
		int ph = e->getH(); if (ph == 0) ph = 64;
		e->grav = true;
		e->grounded = false;

		int colMin = e->x / cell_size - 1;
		int colMax = (e->x + pw) / cell_size + 1;
		if (colMin < 0) colMin = 0;
		if (colMax >= width) colMax = width - 1;

		for (int col = colMin; col <= colMax; col++) {
			int row = worldHeights[col];
			if (lvl[row][col] != 'g') continue;
			int tx = col * cell_size, ty = row * cell_size;
			bool ox = e->x < tx + cell_size && e->x + pw > tx;
			bool oy = e->y < ty + cell_size && e->y + ph > ty;
			if (!ox || !oy) continue;
			int fromBot = (e->y + ph) - ty;
			int fromTop = (ty + cell_size) - e->y;
			if (fromBot < fromTop) { e->y = ty - ph; e->vy = 0; e->grounded = true; }
			else { e->y = ty + cell_size; e->vy = 0; }
		}
		for (int col = colMin; col <= colMax; col++) {
			int row = worldHeights[col];
			if (lvl[row][col] != 'g') continue;
			int tx = col * cell_size, ty = row * cell_size;
			bool ox = e->x < tx + cell_size && e->x + pw > tx;
			bool oy = e->y < ty + cell_size && e->y + ph > ty;
			if (!ox || !oy) continue;
			int fromBot = (e->y + ph) - ty;
			int fromTop = (ty + cell_size) - e->y;
			if (fromBot <= fromTop) continue;
			int left = (tx + cell_size) - e->x;
			int right = (e->x + pw) - tx;
			if (left < right) e->x += left;
			else               e->x -= right;
			e->vx = 0;
		}
	}
	void collideLvl(Entity* p) {
		int pw = p->getW();
		int ph = p->getH();
		p->grav = true;
		p->grounded = false;
		for (int col = 0; col < width; col++) {
			int row = worldHeights[col];
			if (lvl[row][col] != 'g') continue;
			int tx = col * cell_size, ty = row * cell_size;

			bool overlapY = p->getY() < ty + cell_size && p->getY() + ph > ty;
			bool overlapX = p->getX() < tx + cell_size && p->getX() + pw > tx;

			if (overlapX && overlapY) {
				int overlapLeft = (tx + cell_size) - p->x;
				int overlapRight = (p->x + pw) - tx;
				int overlapBottom = (p->y + ph) - ty;
				int overlapTop = (ty + cell_size) - p->y;
				if (overlapBottom > overlapTop) continue;
				if (overlapLeft < overlapRight) p->x += overlapLeft;
				else p->x -= overlapRight;
				p->vx = 0;
			}
		}
		for (int col = 0; col < width; col++) {
			int row = worldHeights[col];
			if (lvl[row][col] != 'g') continue;
			int tx = col * cell_size;
			int ty = row * cell_size;

			bool overlapX = p->x < tx + cell_size && p->x + pw > tx;
			bool overlapY = p->y < ty + cell_size && p->y + ph > ty;

			if (overlapX && overlapY) {
				int overlapTop = (ty + cell_size) - p->y;
				int overlapBottom = (p->y + ph) - ty;
				if (overlapBottom < overlapTop) {
					p->y = ty - ph;
					p->gravity(true);
					p->grounded = true;
				}
				else {
					p->y = ty + cell_size;
					p->vy = 0;
				}
			}
		}
		gravDelay.advance();
		if (gravDelay.finish()) gravDelay.start();
	}
	void updateCamera() {
		Player* p = player;
		int target = p->x + p->getW() / 2 - screen_x / 2;
		int worldW = width * cell_size;
		if (target < 0) target = 0;
		if (target > worldW - screen_x) target = worldW - screen_x;
		camX = target;
	}
	void handlePlayerDeath() {
		if (!player || !player->dead) return;
		if (--player->lives == 0) { delete player; player = nullptr; }
		else player->dead = false;
	}
	void drawHUD(RenderWindow& window) {
		RectangleShape box(Vector2f(80, 80));
		box.setFillColor(Color(40, 40, 40, 200));
		box.setOutlineColor(Color::White);
		box.setOutlineThickness(2);
		box.setPosition(10, screen_y - 90);
		window.draw(box);

		if (player->currentWeapon && player->currentWeapon->weaponSprite) {
			player->currentWeapon->weaponSprite->draw(window, 20, screen_y - 80);
		}
	}
	void draw(RenderWindow& window) {
		bg->draw(window, 0, 0);
		for (int row = 0; row < height; row++)
			for (int col = 0; col < width; col++)
				if (lvl[row][col] == 'g') {
					wallSprite1.setPosition(col * cell_size - camX, row * cell_size);
					window.draw(wallSprite1);
				}
		for (int n = 0; n < enemyCount; n++) {
			if (!enemies[n] || !enemies[n]->exists) continue;
			int edirx = (enemies[n]->vx >= 0) ? 1 : -1;
			double savedX = enemies[n]->x;
			enemies[n]->x = savedX - camX;
			enemies[n]->draw(window, edirx);
			enemies[n]->x = savedX;
		}
		for (int f = 0; f < dropCount; f++) {
			if (!drops[f]) continue;
			double savedX = drops[f]->x;
			drops[f]->x = savedX - camX;
			drops[f]->draw(window);
			drops[f]->x = savedX;
		}
		double screenX = player->x - camX;
		double savedX = player->x;
		player->x = screenX;
		player->draw(window);
		player->x = savedX;
	}
	void update() {
		handlePlayerDeath();
		if (player == nullptr) return;
		updateCamera();
		if(rand()%40==0) cout << "x value: " << player->getX() << "\ty value:" << player->getY() << '\n';
		player->gravity(false||player->introPlaying);
		collideLvl(player);
		for (int n = 0; n < enemyCount; n++) {
			if (!enemies[n] || !enemies[n]->exists) continue;

			enemies[n]->gravity(enemies[n]->grounded);
			collideLvlEnemy(enemies[n]);

			double dx = player->x - enemies[n]->x;
			if (dx > 1) { enemies[n]->vx = 0.6; enemies[n]->setState(EIDLE); }
			else if (dx < -1) { enemies[n]->vx = -0.6; enemies[n]->setState(EIDLE); }
			else { enemies[n]->vx = 0;    enemies[n]->setState(EIDLE); }
			enemies[n]->x += enemies[n]->vx;

			enemies[n]->shootTimer--;
			if (enemies[n]->shootTimer <= 0 && abs(dx) < 400) {
				enemies[n]->shootTimer = 120;
				enemies[n]->setState(EATTACK);
				if (dx < 60) player->reduceHP(1);
			}
			enemies[n]->update();

			int edirx = (enemies[n]->vx >= 0) ? 1 : -1;

			if (!enemies[n]->exists) {
				Food* f = new Food();
				f->x = enemies[n]->x;
				f->y = enemies[n]->y;
				drops[dropCount++] = f;
				delete enemies[n];	enemies[n] = nullptr;
				continue;
			}

		}
		for (int f = 0; f < dropCount; f++) {
			if (!drops[f]) continue;
			double savedX = drops[f]->x;
			drops[f]->x = savedX - camX;
			if (is_colliding(drops[f], player)) {
				player->addHP(20);
				if (player->hp > 100) player->hp = 100;
				delete drops[f]; drops[f] = nullptr;
			}
			drops[f]->x = savedX;
		}


		player->update();
		player->Special();


		if (player->y > screen_y) player->y = 0;
		for (int i = 0; i < enemyCount; i++) {
			if (!playerbullet) break;
			playerbullet->shoot();
		}


		if (player->botState == BOT_RUN && run.getStatus() != Sound::Playing)	run.play();
		else if (player->botState != BOT_RUN)	run.stop();
		if (player->isFiring && shoot.getStatus() != Sound::Playing) shoot.play();
		else if (!player->isFiring)	shoot.stop();


		bool enemyNear = false;
		for (int n = 0; n < enemyCount; n++) {
			if (!enemies[n] || !enemies[n]->exists) continue;
			if (abs((enemies[n]->x - player->x)) < 400) { enemyNear = true; break; }
		}
		if (enemyNear && enemy.getStatus() != Sound::Playing) enemy.play();
		else if (!enemyNear) enemy.stop();
	}
};

class GameState {
public:
	virtual void update(RenderWindow& window) = 0;
	virtual void draw(RenderWindow& window) = 0;
	virtual ~GameState() {}
};

class MenuState : public GameState {
	const char* label;
	Font  font;
	Text  text;
	bool  fontLoaded;
	Music menuMusic;
public:
	MenuState(const char* lbl) : label(lbl), fontLoaded(false) {
		if (font.loadFromFile("../25I-0922_25I-0765_Assets/arial.ttf")) {
			text.setFont(font);
			text.setString(lbl);
			text.setCharacterSize(48);
			text.setFillColor(Color::White);
			text.setPosition(screen_x / 2.f - 200, screen_y / 2.f - 24);
			fontLoaded = true;
		}
		
		menuMusic.openFromFile("../25I-0922_25I-0765_Assets/Audio/menu.ogg");
		menuMusic.setVolume(.3);
		menuMusic.setLoop(true);
		menuMusic.play();
	}

	void update(RenderWindow& window) override {
		if (Keyboard::isKeyPressed(Keyboard::Escape)) window.close();
	}
	void draw(RenderWindow& window) override {
		window.clear(Color(20, 20, 40));
		if (fontLoaded) window.draw(text);
	}
};

class PlayState : public GameState {
	ElementManager* em;
public:
	PlayState(Biome** biomes, int biomeCount) {
		em = new ElementManager(biomes, biomeCount);
	}
	~PlayState() override { delete em; }

	void update(RenderWindow& window) override {
		if (Keyboard::isKeyPressed(Keyboard::Escape)) window.close();
		em->update();
	}
	void draw(RenderWindow& window) override {
		em->draw(window);
	}
};

const int CHUNK_COLS = 50;
const int CHUNK_WINDOW = 6;

struct Chunk {
	int startCol;
	int heights[CHUNK_COLS];
	char tiles[height][CHUNK_COLS];
};

class InfiniteState : public GameState {

	Chunk* window[CHUNK_WINDOW];
	int      windowStart; 
	int      baseSeed;

	Texture  topTex, fillTex, waterTex;
	Sprite   topSpr, fillSpr, waterSpr;
	SpriteData* bg;
	int      camX;

	Player* player;

	static const int    LAYERS = 6;
	static constexpr double ROUGHNESS = 0.5;
	static constexpr double ZOOM = 0.1;
	static const int    BASELINE = 14 - 6;
	static const int    MAX_AMP = 3;

	void generateChunk(Chunk* c, int startCol) {
		c->startCol = startCol;
		for (int i = 0; i < CHUNK_COLS; i++) {
			double n = fractalNoise((startCol + i) * ZOOM,
				baseSeed + startCol * 31,
				LAYERS, ROUGHNESS);
			c->heights[i] = BASELINE - (n * MAX_AMP);
		}
		for (int i = 0; i < CHUNK_COLS; i++)
			for (int row = 0; row < 14; row++)
				c->tiles[row][i] = (row >= c->heights[i]) ? 'g' : '\0';
	}

	int heightAt(int worldCol) const {
		int chunkIdx = worldCol / CHUNK_COLS - windowStart;
		if (chunkIdx < 0) chunkIdx = 0;
		if (chunkIdx >= CHUNK_WINDOW) chunkIdx = CHUNK_WINDOW - 1;
		int localCol = worldCol % CHUNK_COLS;
		return window[chunkIdx]->heights[localCol];
	}

	void streamChunks() {
		int playerChunk = (player->x / cell_size) / CHUNK_COLS;
		int frontChunk = windowStart + CHUNK_WINDOW - 1;
		if (playerChunk + 2 >= frontChunk) {
			delete window[0];
			for (int i = 0; i < CHUNK_WINDOW - 1; i++) window[i] = window[i + 1];
			int newStart = (windowStart + CHUNK_WINDOW) * CHUNK_COLS;
			window[CHUNK_WINDOW - 1] = new Chunk();
			generateChunk(window[CHUNK_WINDOW - 1], newStart);
			windowStart++;
		}
	}


	void collideLvl() {
		int pw = player->getW();
		int ph = player->getH();
		player->grav = true;
		player->grounded = false;

		int colMin = player->x / cell_size - 1;
		int colMax = (player->x + pw) / cell_size + 1;

		for (int col = colMin; col < colMax; col++) {
			if (col < 0) continue;
			int h = heightAt(col);
			int tx = col * cell_size, ty = h * cell_size;

			bool overlapY = player->getY() < ty && player->getY() + ph > ty;
			bool overlapX = player->getX() < tx + cell_size && player->getX() + pw > tx;

			if (overlapX && overlapY) {
				int overlapLeft = (tx + cell_size) - player->x;
				int overlapRight = (player->x + pw) - tx;
				int overlapBottom = (player->y + ph) - ty;
				int overlapTop = (ty + cell_size) - player->y;
				if (overlapBottom > overlapTop) continue;
				if (overlapLeft < overlapRight) player->x += overlapLeft;
				else player->x -= overlapRight;
				player->vx = 0;
			}
		}
		for (int col = 0; col < width; col++) {
			if (col < 0) continue;
			int h = heightAt(col);
			int tx = col * cell_size, ty = h * cell_size;

			bool overlapX = player->x < tx + cell_size && player->x + pw > tx;
			bool overlapY = player->y < ty && player->y + ph > ty;

			if (overlapX && overlapY) {
				int overlapTop = (ty + cell_size) - player->y;
				int overlapBottom = (player->y + ph) - ty;
				if (overlapBottom < overlapTop) {
					player->y = ty - ph+cell_size;
					player->gravity(true);
					player->grounded = true;
				}
				else {
					player->y = ty;
					player->vy = 0;
				}
			}
		}
	}

	void loadPlayer() {
		AnimRow InitialDrop = { 7, 5, 29, 240 };
		player = new Player("Marco Rossi", 409, -150, 60, 0, 10);
		player->setIntroAnimation(new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Intro.png", InitialDrop, 3, 5, false));
		player->totalHeight = player->topOffsetY + 54;
		player->totalWidth = 21 * 3;
		AnimRow Idle = { 5, 5, 32, 28 };
		AnimRow Shoot = { 3, 3, 53, 23 };
		player->setTopState(TOP_IDLE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Idle.png", Idle, 3, 15));
		player->setTopState(TOP_SHOOT, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Shoot.png", Shoot, 3, 15));
		player->setTopState(TOP_MELEE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Top Idle.png", Idle, 3, 15));
		Idle = { 1, 0, 21, 16 };
		AnimRow Run = { 3, 2, 20, 20 };
		AnimRow Jump = { 3, 4, 20, 24 };
		AnimRow Death = { 8, 1, 39, 31 };
		player->setBotState(BOT_IDLE, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Idle.png", Idle, 3, 15));
		player->setBotState(BOT_RUN, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Run.png", Run, 3, 10));
		player->setBotState(BOT_JUMP, new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Bot Jump.png", Jump, 3, 10));
		player->setDeathAnimation(new SpriteData("../25I-0922_25I-0765_Assets/Marco Rossi Death.png", Death, 3, 10));
	}

public:
	InfiniteState() : windowStart(0), camX(0), player(nullptr) {
		baseSeed = rand();
		for (int i = 0; i < CHUNK_WINDOW; i++) {
			window[i] = new Chunk();
			generateChunk(window[i], i * CHUNK_COLS);
		}
		topTex.loadFromFile("../25I-0922_25I-0765_Assets/blocks/grass_block_side.png");
		topSpr.setTexture(topTex);
		fillTex.loadFromFile("../25I-0922_25I-0765_Assets/blocks/dirt.png");
		fillSpr.setTexture(fillTex);
		waterTex.loadFromFile("../25I-0922_25I-0765_Assets/blocks/deepslate_top.png");
		waterSpr.setTexture(waterTex);
		AnimRow bgRow = { 1, 0, 792, 176 };
		bg = new SpriteData("../25I-0922_25I-0765_Assets/backgrounds.png", bgRow, (screen_y / 176.0), 0, false);
		loadPlayer();
	}
	~InfiniteState() override {
		for (int i = 0; i < CHUNK_WINDOW; i++) delete window[i];
		delete player;
		delete bg;
	}

	void update(RenderWindow& window) override {
		if (Keyboard::isKeyPressed(Keyboard::Escape)) window.close();
		if (!player) return;
		streamChunks();
		player->gravity(false || player->introPlaying);
		collideLvl();
		player->update();
		player->Special();
		if (player->y > screen_y) player->y = -150;   // respawn
		int target = player->x + player->getW() / 2 - screen_x / 2;
		if (target < 0) target = 0;
		camX = target;
	}

	void draw(RenderWindow& w) override {
		bg->draw(w, 0, 0);
		int firstCol = camX / cell_size - 1;
		int lastCol = (camX + screen_x) / cell_size + 1;
		for (int col = firstCol; col <= lastCol; col++) {
			if (col < 0) continue;
			int h = heightAt(col);
			double sx = (col * cell_size - camX);
			topSpr.setPosition(sx, (h * cell_size));
			w.draw(topSpr);
			for (int row = h + 1; row < 14; row++) {
				fillSpr.setPosition(sx, (row * cell_size));
				w.draw(fillSpr);
			}
			if (h <= 0) { waterSpr.setPosition(sx, cell_size); w.draw(waterSpr); }
		}
		double savedX = player->x;
		player->x = savedX - camX;
		player->draw(w);
		player->x = savedX;
	}
};

class GameStateManager {
	GameState* current;
	Biome** biomes;
	int        biomeCount;

public:
	GameStateManager() : current(nullptr), biomes(nullptr), biomeCount(0) {}

	void setBiomes(Biome** b, int count) { biomes = b; biomeCount = count; }
	void setState(GameState* s) { current = s; }

	GameState* getCurrent() { return current; }
	PlayState* makePlayState() {return new PlayState(biomes, biomeCount);}
	InfiniteState* makeInfinState() {return new InfiniteState();}

	void run(RenderWindow& window) {
		if (!current) return;
		window.clear();
		current->update(window);
		current->draw(window);
	}
};

class Spawn {
public:
	int enemy_count = 0;
	Biome* b;
	Zombie* z;
	PlayState* play_state;
	RebelSoldier* rbsoldier;
	ShieldedSoldier* soldier;
	BazookaSoldier* bazooka; GrenadeSoldier* gr_soldr; FlyingTara* tara;
	void batches(int l = 1) {
		if (l == 1) {
			int count = 2;
			rbsoldier = new RebelSoldier[2];   //this can work is this error solves
			soldier = new  ShieldedSoldier[2];
			bazooka = new BazookaSoldier[2];
			gr_soldr = new GrenadeSoldier[2];
			tara = new FlyingTara();

			PowPrisoner* p;
			Enemy_sub* en;
			p = new  PowPrisoner();
			en = new Enemy_sub();
			for (int i = 0; i < 2; i++) {
				rbsoldier[i].setX(100 + i);
				soldier[i].setX(220 + i * 2);
				bazooka[i].setX(270);
				gr_soldr[i].setX(300 + i);

			}
			tara->setX(150);
		}
		else if (l == 2) {
			rbsoldier = new RebelSoldier[3];   //this can work is this error solves
			soldier = new  ShieldedSoldier[3];
			bazooka = new BazookaSoldier[3];
			gr_soldr = new GrenadeSoldier[3];
			z = new Zombie[3];
			for (int i = 0; i < 3; i++) {
				rbsoldier[i].setX(100 + i);
				soldier[i].setX(220 + i * 2);
				bazooka[i].setX(270);
				gr_soldr[i].setX(300 + i);

			}   z->setX(100);
		}
		else if (l == 3) {
			rbsoldier = new RebelSoldier[4];   //this can work is this error solves
			soldier = new  ShieldedSoldier[4];
			bazooka = new BazookaSoldier[4];
			gr_soldr = new GrenadeSoldier[4];
			z = new Zombie[3];
			for (int i = 0; i < 4; i++) {
				rbsoldier[i].setX(100 + i);
				soldier[i].setX(220 + i * 2);
				bazooka[i].setX(270);
				gr_soldr[i].setX(300 + i);

			}   z->setX(100);
		}
	}
};

class Game {
protected:
	static const int MAX_STATES = 6;
	GameState* states[MAX_STATES];
	int              activeState;
	GameStateManager gsm;

	Biome* biomes[3];

	void buildBiomes() {
		int third = width / 3;
		biomes[0] = new Biome("plains", 0, third);
		biomes[1] = new Biome("aerial", third, third * 2, 6, 0.4, 0.03, height - 8, 5);
		biomes[2] = new Biome("aquatic", third * 2,width, 6, 0.6, 0.05, height - 3, 2);
		gsm.setBiomes(biomes, 3);
	}
public:
	Game() : activeState(0) {
		for (int i = 0; i < MAX_STATES; i++) states[i] = nullptr;
		buildBiomes();

		states[0] = new MenuState("METAL SLUG: Press ENTER");
		states[1] = new MenuState("SELECT LEVEL: 1 / 2 / 3 / INF");
		for(int i=2;i<5;i++)
			states[i] = gsm.makePlayState();
		states[5] = gsm.makeInfinState();

		activeState = 0;
		gsm.setState(states[activeState]);
	}
	void handleStateTransitions(RenderWindow& window) {
		if (activeState == 0 && Keyboard::isKeyPressed(Keyboard::Return)) {
			activeState = 1;
			gsm.setState(states[activeState]);
		}
		else if (activeState == 1) {
			if (Keyboard::isKeyPressed(Keyboard::Num1)) { activeState = 2; gsm.setState(states[2]); }
			if (Keyboard::isKeyPressed(Keyboard::Num2)) { activeState = 3; gsm.setState(states[3]); }
			if (Keyboard::isKeyPressed(Keyboard::Num3)) { activeState = 4; gsm.setState(states[4]); }
			if (Keyboard::isKeyPressed(Keyboard::Num4)) { activeState = 5; gsm.setState(states[5]); }
		}
	}

	void run(RenderWindow& window) {
		handleStateTransitions(window);
		gsm.run(window);
	}
};
