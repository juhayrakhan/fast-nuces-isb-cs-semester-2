#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int block_wid = 2;
int block_heig = 2;
int screen_x = 1600;
int screen_y = 900;

const int cell_size = 64, height = 14, width = 102;

class loopint {
	int val, max;
public:
	loopint(int max = 1) : val(0), max(max) {}
	void operator++(int) { val++; if (val >= max) val = 0; }
	operator int() { return val; }
	bool operator()() { return val == max - 1; }
	void operator=(int n) { val = (n < max ? n : max - 1); }
	int getmax() const { return max; }
};

class CoolDown {
private: int value, max; bool running;
public:
	CoolDown(int total = 60, bool running = false)
		: max(total), value(running ? total : 0), running(running) {}
	void start() { value = max; running = true; }
	void stop() { running = false; value = 0; }
	void advance() {
		if (!running) return;
		value--;
		if (value < 0) value = 0;
	}
	bool finish() {
		if (running && value == 0) { running = false; return true; }
		return false;
	}
	bool isRunning() { return running; }
};

struct AnimRow {
	int count, spacingx, width, height;
};
class SpriteData {
private:
	loopint frame;
	CoolDown delay;
	Sprite sprite;
	Texture texture;
	IntRect region;
	int spacingx;
	int scalefactor;
	bool loop;
public:
	SpriteData(const char* path, AnimRow data, int scale = 1, int animDelay = 10, bool loop = true) :
	spacingx(data.spacingx), frame(data.count),
		delay(animDelay, true), loop(loop), scalefactor(scale) {
		region = IntRect(0, 0, data.width, data.height);
		texture.loadFromFile(path);
		sprite.setTexture(texture);
		sprite.setScale(scale, scale);
		sprite.setTextureRect(IntRect(0, 0, region.width, region.height));
	}
	void draw(RenderWindow& window, double x, double y, int dir = 1, bool animate = true) {
		if (animate && delay.finish()) {
			if (loop || !frame()) frame++;
			int texX = frame * (region.width + spacingx);
			sprite.setTextureRect(IntRect(texX, 0, region.width, region.height));
			delay.start();
		}
		if (dir == -1) {
			sprite.setScale(-scalefactor, scalefactor);
			sprite.setPosition(x + region.width * scalefactor, y);
		}
		else {
			sprite.setScale(scalefactor, scalefactor);
			sprite.setPosition(x, y);
		}
		delay.advance();
		window.draw(sprite);
	}
	bool isFinished() { return frame(); }
	int x() { return region.left; }		int y() { return region.top; }
	int h() { return region.height; }  int w() { return region.width; }
	int scale() { return scalefactor; }
};

const int INIT = -1, HIT = 4;
const int totalstatecount = 5;
const int BOT_IDLE = 0, BOT_RUN = 1, BOT_JUMP = 2;
const int BOT_COUNT = 3;
const int TOP_IDLE = 0, TOP_SHOOT = 1, TOP_MELEE = 2;
const int TOP_COUNT = 3;

const int IDLE = 0, RUN = 1, ATTACK = 2, JUMP = 3;
const int EIDLE = 0, EATTACK = 1, EDEAD = 2;

class Element {
protected:
	SpriteData** states;
	int statecount;
	int current;
	int next;
	bool locked;
	CoolDown pauseDelay;
	char* name;
	void copy(const char* a) {
		if (!a) return;
		int len = 0;
		while (a[len] != '\0') len++;
		if (len == 0) return;
		name = new char[len + 1];
		for (int i = 0; i <= len; i++) name[i] = a[i];
	}
public:
	bool exists = true;
	double x, y;
	char type;
	int hp;
	Element(const char* elementname, double x, double y, int count=totalstatecount) :
		x(x), y(y), current(IDLE), next(IDLE), locked(false), pauseDelay(15, false), hp(0), type('\0') {
		states = new SpriteData*[count];
		for (int i = 1; i < count; i++) states[i] = nullptr;
		copy(elementname);
		current = IDLE;
	}
	void setState(int s, bool lock = false) {
		if (locked) return;
		next = s;
		locked = lock;
	}
	void setSprite(loopint s, SpriteData* data) { states[s] = data; }
	void update() {
		if (pauseDelay.isRunning()) {
			pauseDelay.advance();
			if (pauseDelay.finish()) current = next;
			return;
		}
		if (states[current] == nullptr) return;
		if (states[current]->isFinished()) {
			if (locked) { locked = false; next = IDLE; }
			if (current != next) pauseDelay.start();
		}
	}
	virtual void draw(RenderWindow& window, int dirx=1) {
		if (states[current] == nullptr) return;
		bool animate = !pauseDelay.isRunning();
		states[current]->draw(window, x, y, dirx, animate);
	}
	virtual void move(int x, int y) {
		this->x += x;
		this->y += y;
	}
	const char* getName() { return name; }
	virtual int getX() { return x; }
	virtual int getY() { return y; }
	virtual int getW() { return states[current] ? states[current]->w() * states[current]->scale() : 0; }
	virtual int getH() { return states[current] ? states[current]->h() * states[current]->scale() : 0; }
	virtual void reduce_hp(int n) { this->hp -= n; }
	~Element() {
		delete[] name;
	}
};

bool compare(const char* a, const char* b) {
	int i = 0;
	for (; a[i] && b[i]; i++)
		if (a[i] != b[i]) return false;
	if (a[i] != b[i]) return false;
	return true;
}

class Entity : public Element {
public:
	int hp;
	bool grounded;
	double vx, vy;
	bool grav;

	Entity(const char* elementname, double x, double y, int hp, double vx, double vy) :
		Element(elementname, x, y), hp(hp), vx(vx), vy(vy), grav(true) {
	}
	const int getHP() const { return hp; }
	void setHP(int value) { hp = value; }
	void addHP(int extra) { hp += extra; }
	void setX(int a) { x = a; }
	void setY(int a) { y = a; }
	virtual bool reduceHP(int dmg) {
		hp -= dmg;
		if (hp <= 0) {
			hp = 0;
			exists = false;
		}
		return exists;
	}
	void gravity(bool grounded) {
		if (!grav) return;
		double gravity = 0.7, terminal = 5;
		if (grounded) { vy = 0; return; }
		vy += gravity;
		if (vy > terminal) vy = terminal;
		y += vy;
	}
};


bool is_colliding(Element* e1, Element* e2) {
	if (e1->getX() < e2->getX() + e2->getW() && e1->getX() + e1->getW() > e2->getX()
		&& e1->getY() < e2->getY() + e2->getH() && e1->getY() + e1->getH() > e2->getY())
		return true;
	return false;
}
