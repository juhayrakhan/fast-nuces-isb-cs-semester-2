#pragma once
#include"../25I-0922_25I-0765_Headers/GameEngine.h"

class LevelManager {
protected:
	int MAX_level = 4;
	static int current_count;
	Spawn* spawn;
	bool level_passed[4];
public:
	void start_level() {
		spawn->batches(current_count);
	}
	void levelsDone() {    //checked by if we pased the level calculated by scores
		level_passed[current_count] = true;
	}
	void nextLevel() {
		if (level_passed[current_count] = true)
			current_count += 1;
	}
};
int LevelManager::current_count = 1;

class PlayState {
protected:
	char* state1; char* state2; char* current;
public:
	LevelManager manag;
	PlayState(int i = 1) {       //we will set the values of states later when i will confirm ehst exactly these are
		if (i == 1)
			current = state1;
		else if (i == 2)
			current = state2;
		else
			current = state1;

	};
};