"25I-0922_25I-0765_Headers once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Window.hpp>
#include "../25I-0922_25I-0765_Headers/Element_Entity.h"
#include "../25I-0922_25I-0765_Headers/Header.h"
using namespace std;

class Transformation;

class Soldier {   //base of player and trasmformation
public:
	Soldier* s;
	Soldier() {}
	void check_soldier() {}
};

class Player :public Entity, public Soldier {
protected:
public:
	// 'char type' (shadowed Element) — both caused split state / UB.
	double ax, maxspeedx;
	Grenade** grenades;
	int grenadecount;
	int specialActiveTime;
	int maxActiveSpecialTime;
	int lives;
	MeleeAttack meleeAttack;
	double grenadeThrowdist;
	int meleeCooldown, damageCooldown, maxDamageCooldown;
	bool immune;
	Weapon* weapon[6];
	Weapon* currentWeapon;
	Bullet* ammo;
	int ammocount;
	Pistol pistol;
	int saturation;
	Vehicle* piloting;
	bool isFiring;
	bool is_mummy;
	bool is_zombie;

	SpriteData* introAnim;
	bool introPlaying;

	SpriteData* topStates[TOP_COUNT];
	SpriteData* botStates[BOT_COUNT];
	int topState;
	int botState;
	int topOffsetY;
	int totalHeight;
	int totalWidth;
	int landingFrames;

	SpriteData* deathAnim;
	bool deathPlaying;
	bool dead;

	int dirx;
	CoolDown inputdelay;
	char state;
	Transformation* trs;

	Player(const char* name, int x, int y, int hp, double vx, double vy) :
		Entity(name, x, y, hp, vx, vy), ax(0.5), maxspeedx(5), meleeAttack(1) {
		inputdelay = CoolDown(1);
		inputdelay.start();
		dirx = 1;
		piloting = nullptr;
		type = 'p';
		grenades = nullptr;
		grenadecount = 0;
		specialActiveTime = 0;
		maxActiveSpecialTime = 100;
		lives = 3;
		grenadeThrowdist = 0;
		meleeCooldown = 0;
		damageCooldown = 0;
		maxDamageCooldown = 30;
		immune = false;
		for (int wi = 0; wi < 6; wi++) weapon[wi] = nullptr;
		currentWeapon = nullptr;
		ammo = nullptr;
		ammocount = 0;
		saturation = 0;
		isFiring = false;
		is_mummy = false;
		is_zombie = false;
		state = '\0';
		trs = nullptr;
		s = nullptr;
		grounded = false;
		deathAnim = nullptr;
		deathPlaying = false;
		dead = false;
		introAnim = nullptr;
		introPlaying = true;
		topOffsetY = 66;
		topState = TOP_IDLE;
		botState = BOT_IDLE;
		for (int i = 0; i < TOP_COUNT; i++) topStates[i] = nullptr;
		for (int i = 0; i < BOT_COUNT; i++) botStates[i] = nullptr;
	}
	void setIntroAnimation(SpriteData* anim) { introAnim = anim; }
	void setDeathAnimation(SpriteData* anim) { deathAnim = anim; }
	void setTopState(int s, SpriteData* data) {
		if (s >= 0 && s < TOP_COUNT) topStates[s] = data;
	}
	void setBotState(int s, SpriteData* data) {
		if (s >= 0 && s < BOT_COUNT) botStates[s] = data;
	}
	void choose_weapon(int n) {
			 if (n == 0) currentWeapon = new HandGrenade();
		else if (n == 1) currentWeapon = new FireBombGrenade();
		else if (n == 2) currentWeapon = new FireArm();
		else if (n == 3) currentWeapon = new Pistol();
		else if (n == 4) currentWeapon = new FlameShot();
		else if (n == 5) currentWeapon = new HeavyMachineGun();
		else if (n == 6) currentWeapon = new RocketLauncher();
		else if (n == 7) currentWeapon = new LaserGun();
	}
	virtual void update() {
		if (introPlaying) {
			if (introAnim == nullptr || introAnim->isFinished()) introPlaying = false;
			return;
		}
		if (deathPlaying) {
			if (deathAnim == nullptr || deathAnim->isFinished()) {
				deathPlaying = false;
				dead = true;
			}
			return;
		}
		tickCooldowns();
		move();
		attack();
	}
	void convertTo_mummy(Player* p) { p->is_mummy = true; }
	void convertTo_Zombie(Player* p);
	void move() {
		if (Keyboard::isKeyPressed(Keyboard::Right)) {
			dirx = 1;
			botState = BOT_RUN;
			vx += ax;
			if (vx > maxspeedx) vx = maxspeedx;
		}
		else if (Keyboard::isKeyPressed(Keyboard::Left)) {
			dirx = -1;
			botState = BOT_RUN;
			vx -= ax;
			if (vx < -maxspeedx) vx = -maxspeedx;
		}
		else {
			botState = BOT_IDLE;
			if (vx > 0) { vx -= ax; if (vx < 0) vx = 0; }
			if (vx < 0) { vx += ax; if (vx > 0) vx = 0; }
		}
		x += vx;
		if (Keyboard::isKeyPressed(Keyboard::Up) && grounded) {
			vy = -10;
			grounded = false;
			grav = true;
			botState = BOT_JUMP;
		}
		if (!grounded) botState = BOT_JUMP, landingFrames = 0;
		else {
			landingFrames = 0;
			botState = (vx != 0) ? BOT_RUN : BOT_IDLE;
		}
	}

	int getW() { return totalWidth;}
	int getH() { return totalHeight; }
	void draw(RenderWindow& window) const {
		if (introPlaying && introAnim) {
			introAnim->draw(window, x, y, dirx, true);
			return;
		}
		if (deathPlaying && deathAnim) {
			deathAnim->draw(window, x, y, dirx, true);
			return;
		}
		SpriteData* top = topStates[topState];
		SpriteData* bot = botStates[botState];
		double drawx = x;
		if (bot) {
			if (dirx == -1) drawx += top->w();
			int botH = bot->h() * bot->scale();
			bot->draw(window, drawx, y + totalHeight - botH, dirx, true);
		}
		int topx = x;
		if (top) {
			if (topState == TOP_SHOOT && dirx == -1)
				topx -= (topStates[TOP_SHOOT]->w());
			top->draw(window, topx, y, dirx, true);
		}
	}
	void attack(int dir = 1) {
		if (!Keyboard::isKeyPressed(Keyboard::E)) {
			isFiring = false;
			topState = TOP_IDLE;
			return;
		}
		isFiring = true;
		topState = TOP_SHOOT;
		//if(currentWeapon) currentWeapon->shoot(1,2,3);
	}
	virtual void Special() {}
	void activateSpecial() { specialActiveTime = maxActiveSpecialTime; }
	bool checkSpecial() {
		return specialActiveTime;
	}
	virtual bool reduceHP(int dmg) {
		if (damageCooldown > 0) return true;
		hp -= dmg;
		damageCooldown = maxDamageCooldown;
		if (hp <= 0) {
			hp = 0;
			dead = true;
		}
		return !dead;
	}
	void tickCooldowns() {
		if (damageCooldown > 0) damageCooldown--;
	}
	int AttackMelee(Enemy& e) {
		// implement compare and enemy above;
		// enemy mein operator overload == with name;
		//if (meleeAttack.canBreakShields() && compare(e.name, "ShieldedSoldier") {
		//	e.reduceHP(meleeAttack.damage);
		//}
	}

	void addVehicle(Vehicle* v) {
		piloting = v;

	}

	// implement Tranform(Undead* u)
};



class MarcoRossi : public Player {
public:
	MarcoRossi(const char* name, int x, int y, int width,
		int height, int hp, double vx, double vy) :
		Player(name, x, y, hp, vx, vy) {
	}
	void Special() {
		currentWeapon->wp_setFire(currentWeapon->wp_getFire() * 1.25);
		specialActiveTime--;
		if (specialActiveTime <= 0) specialActiveTime = 0;
		if (isFiring) {
			attack(-1);
		}
	}
};

class Tarma : public Player {
public:
	Tarma(const char* name, int x, int y, int hp, double vx, double vy) :
		Player(name, x, y, hp, vx, vy) {
		hp -= hp * 0.2; maxspeedx -= maxspeedx * 0.2;
	}
	void Special() {
		immune = true;
		//piloting->immune = true;
		specialActiveTime--;
		if (specialActiveTime <= 0) {
			immune = false;
			//piloting->immune = false;
			specialActiveTime = 0;
		}
	}
};

class EriKasamoto : public Player {
public:
	EriKasamoto(const char* name, int x, int y, int hp, double vx, double vy) :
		Player(name, x, y, hp, vx, vy) {
		grenadecount *= 2;
	}
	void Special() {
		currentWeapon->wp_setFire(currentWeapon->wp_getFire() * 0.8);
		if (specialActiveTime == maxActiveSpecialTime) {
			// double the grenade array, and make ALL throwdist +=2;
		}
		specialActiveTime--;
		if (specialActiveTime <= 0) {
			// turn all remaining throwdistances to og, -=2;
			specialActiveTime = 0;
		}
	}
};

class FiolinaGermi : public Player {
public:
	FiolinaGermi(const char* name, int x, int y, int hp, double vx, double vy) :
		Player(name, x, y, hp, vx, vy) {
		grenadecount -= 2;
		meleeAttack.setMelDam(meleeAttack.getMeleeDam() - meleeAttack.getMeleeDam() * 0.20);
	}
	void Special() {
		if (currentWeapon == nullptr) return;
		if (specialActiveTime == maxActiveSpecialTime) {
			int d = currentWeapon->wp_getFire();
			currentWeapon->wp_setFire(d * 2);
		}
		specialActiveTime--;
		if (specialActiveTime <= 0) {
			int d = currentWeapon->wp_getFire();
			currentWeapon->wp_setFire(d * 0.5);
			specialActiveTime = 0;
		}
	}
};

class FusionCompanion : public Player {
public:
	FusionCompanion(const char* name, int x, int y, int hp, double vx, double vy) :
		Player(name, x, y, hp, vx, vy) {
	}
	void Special() {}
	void activateSpecial() {}
	void checkSpecial() {}
};


class Transformation : public Soldier, public Zombie, public MummyWarrior {
public:
	Zombie* zombie;
	Transformation() {}
	Zombie* change_to_zombie(Player* p) {
		zombie = (Zombie*)p; return zombie;
	}   //also load the textyre
	void change_to_zombie() {}
};

void Player::convertTo_Zombie(Player* p) {
	if (is_zombie && trs != nullptr) {
		trs->change_to_zombie(p);      //cant define it earlier??/
	}
}

class Collectible : public Element {
protected:
	int damage;

public:
	SpriteData* coll_sprite;
	Collectible() : Element("", 0, 0) {
		damage = 0;
	}
};

class Food : public Collectible {
protected:
	char c;
public:
	Food(){
		c = (rand() % 3 ? 't' : 'f');
	}
	void FoodSupply(char ch, Player* p) {
		if (is_colliding(this, p)) {
			if (ch == 't') {
				c = 't';
				p->saturation += 30;
			}
			if (ch == 'f') {
				c = 'f';
				p->saturation += 20;
			}
		}
		else
			return;
	}

};
class SupplyCrate : public Collectible {
public:
	int ran;
	SupplyCrate() {}
	void supply(Player* play) {
		char crate[10] = { 'f','f','h','h','h','m','m','l','p' };
		int w_ind = rand() % 7;
		if (crate[w_ind] == 'f') {
			cout << "RocketLauncher";
			if (Keyboard::isKeyPressed(Keyboard::Y))
				play->currentWeapon = new FireBombGrenade();
			else
				return;
		}
		else if (crate[w_ind] == 'h') {
			cout << "Heavy Machine";
			if (Keyboard::isKeyPressed(Keyboard::Y))
				play->currentWeapon = new HandGrenade();
			else
				return;
		}
		else if (crate[w_ind] == 'm') {
			cout << "FlameShot";
			if (Keyboard::isKeyPressed(Keyboard::Y))
				play->currentWeapon = new FlameShot();
			else
				return;
		}
		else if (crate[w_ind] == 'l') {
			cout << "laserGun";
			if (Keyboard::isKeyPressed(Keyboard::Y))
				play->currentWeapon = new LaserGun();
			else
				return;
		}
		else if (crate[w_ind] == 'p') {
			cout << "pistol";
			if (Keyboard::isKeyPressed(Keyboard::Y))
				play->currentWeapon = new Pistol();
			else
				return;
		}
	}
};
class PowPrisoner : public Collectible {
public:
	SupplyCrate sup;
	bool is_released; int x; int y;
	PowPrisoner() {
		is_released = false;
	}
	bool is_powPrisoner(Player* p) {
		if (p->x == this->x || p->x == this->x + 1 || p->x == this->x + 2)
			if (Keyboard::isKeyPressed(Keyboard::F)) {
				is_released = true;
				sup.supply(p);
			}
	}

};

void FlyingTara::dropGrenade(Player* p) {
		if (this->y == p->y) {
			gr->blast(this->x, this->y, -1, p);
		}
}

void M15A::dropGrenade(Player* p) {
	gr->blast(this->x, this->y, -1, p);
}

void Enemy_sub::dropGrenade(Player* p) {
	rock.blast(this->x, this->y, -1, p);
}
void SlugFlyer::dropGrenade(Player* p) {
	missile->shoot(this->x, this->y, 1, *p);
}

void MetalSlug::shoot(Player* p) {
	flam.shoot(this->x, this->y, -1, *p);
}

void SlugMariner::dropGrenade(Player* p) {
	missile[0].shoot(this->x, this->y, 1, *p);
}